enZombie Settings Remove Zombies v1.0
https://github.com/ErrorNull0/enZombiesSettings

Removes specific zombies from spawning in the game. 

The mod is intended for use with the main enZombies mod.

enzombies mod page:
https://community.7daystodie.com/topic/24594-enzombies-more-zombie-variations/
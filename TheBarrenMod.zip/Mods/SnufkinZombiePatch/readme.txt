Snufin Zombie Patch for enZombies v1.1
https://community.7daystodie.com/topic/22698-snufkins-custom-server-side-zombies-plus-a20/

This patch does two things:

1) Modifies the Snufkin custom zombies mod to work with enZombies. Specifically, it appends the new spawning groups required by enZombies into the entitygroups.xml file. This results in more control over which Snufkin zombies spawn in which biome situation.

2) Provides the option to enable zombie body harvesting for the Snufkin zombies. Go to the entityclassses.xml file to enable this.


Version 1.1:
- removed reference to wasteland game animal spawning

Version 1.0:
- removed the full Snufkin Add-on and use a simpler patch design
